package com.ru.usty.scheduling.visualization;

public class ProcessDescription {

	public int arrivalTime;
	public int serviceTime;

	public ProcessDescription(int arrivalTime, int serviceTime) {
		this.arrivalTime = arrivalTime;
		this.serviceTime = serviceTime;
	}
}
